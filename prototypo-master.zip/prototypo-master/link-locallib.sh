npm link prototypo.js
npm link prototypo-canvas
