const config = require('./local.config.js');

config['if-loader'] = 'debug';

module.exports = config;
